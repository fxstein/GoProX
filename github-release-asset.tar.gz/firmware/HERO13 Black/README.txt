Official firmware for HERO13 Black must be downloaded from GoPro's support page:
https://community.gopro.com/s/article/HERO13-Black-Firmware-Update-Instructions?language=en_US
 
After downloading, create a subfolder named after the version number (e.g., H23.01.01.10.00/) and place the firmware files and a download.url file with the source link inside. 