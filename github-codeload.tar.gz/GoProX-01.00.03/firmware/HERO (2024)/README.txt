Official firmware for HERO (2024) must be downloaded from GoPro's support page:
https://community.gopro.com/s/article/Software-Update-Release-Information?language=en_US
 
After downloading, create a subfolder named after the version number (e.g., H24.01.01.10.00/) and place the firmware files and a download.url file with the source link inside. 